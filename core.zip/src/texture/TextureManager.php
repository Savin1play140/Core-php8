<?php
namespace server\Core\textures;
// server\Core\textures\TextureManager
class TextureManager {
	private $textures;
	public function __constants() {}
	public function loadAll() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/textures/";
		$files = scandir($dir);
		foreach ($files as $zip) {
			if (!str_contains($zip, ".")) {
				if (is_dir($dir.$zip)) {
					$content = file_get_contents($dir.$zip."/manifest.json");
					$texture = json_decode($content, true);
					echo "[SERVER-LOG-ALERT] dir \"".$dir.$zip."\" found <br>";
				}
			}
		}
	}
	public function load($zip) {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/textures/";
		if (!str_contains($zip, ".")) {
			if (is_dir($dir.$zip)) {
				$content = file_get_contents($dir.$zip."/manifest.json");
				$texture = json_decode($content, true);
				echo "[SERVER-LOG-ALERT] dir \"".$dir.$zip."\" found <br>";
			}
		}
	}
}