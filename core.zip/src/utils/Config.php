<?php
namespace server\Core\utils;
define('PATH_TO_MODELS',$_SERVER['DOCUMENT_ROOT'].'/core/src/');

include_once PATH_TO_MODELS."network/".'User.php';
include_once PATH_TO_MODELS.'Server.php';
include_once PATH_TO_MODELS."network/".'Sender.php';
include_once PATH_TO_MODELS."system/".'Log.php';
include_once PATH_TO_MODELS."utils/"."Json.php";
class Config {
	public const DETECT = -1; //Detect by file extension
	public const PROPERTIES = 0; // .properties
	public const CNF = Config::PROPERTIES; // .cnf
	public const JSON = 1; // .js, .json
	public const YAML = 2; // .yml, .yaml
	//const EXPORT = 3; // .export, .xport
	public const SERIALIZED = 4; // .sl
	public const ENUM = 5; // .txt, .list, .enum
	public const ENUMERATION = Config::ENUM;

	public static $format = [
		"json" => Config::JSON,
		"yml" => Config::YAML,
		"txt" => Config::ENUM,
		"list" => Config::ENUM,
		"enum" => Config::ENUM,
		"properties" => Config::PROPERTIES
	];

	public function __construct(string $file, int $type = Config::DETECT, array $default = []){
		$this->load($file, $type, $default);
	}

	private function loadJson(string $file) : void{
		$this->file = $file;

		$this->type = $type;
		if($this->type === Config::DETECT){
			$extension = strtolower(Path::getExtension($this->file));
			if(isset(Config::$formats[$extension])){
				$this->type = Config::$formats[$extension];
			}else{
				throw new \InvalidArgumentException("Cannot detect config type of " . $this->file);
			}
		}

		if(!file_exists($file)){
			$this->config = $default;
			$this->save();
		}else{
			$content = file_get_contents($this->file);
			if($content === false){
				throw new \RuntimeException("Unable to load config file");
			}
			$config = json_decode($content, true, flags: JSON_THROW_ON_ERROR);
				case Config::YAML:
					$content = self::fixYAMLIndexes($content);
					try{
						$config = ErrorToExceptionHandler::trap(fn() => yaml_parse($content));
					}catch(\ErrorException $e){
						throw ConfigLoadException::wrap($this->file, $e);
					}
					break;
				case Config::SERIALIZED:
					try{
						$config = ErrorToExceptionHandler::trap(fn() => unserialize($content));
					}catch(\ErrorException $e){
						throw ConfigLoadException::wrap($this->file, $e);
					}
					break;
				case Config::ENUM:
					$config = array_fill_keys(self::parseList($content), true);
					break;
				default:
					throw new \InvalidArgumentException("Invalid config type specified");
			}
			if(!is_array($config)){
				throw new ConfigLoadException("Failed to load config $this->file: Expected array for base type, but got " . get_debug_type($config));
			}
			$this->config = $config;
			if($this->fillDefaults($default, $this->config) > 0){
				$this->save();
			}
		}
	}
	public function save() : void{
		$content = null;
		switch($this->type){
			case Config::JSON:
				$content = json_encode($this->config, $this->jsonOptions | JSON_THROW_ON_ERROR);
				break;
			case Config::YAML:
				$content = yaml_emit($this->config, YAML_UTF8_ENCODING);
				break;
			case Config::SERIALIZED:
				$content = serialize($this->config);
				break;
			case Config::ENUM:
				$content = self::writeList(array_keys($this->config));
				break;
			default:
				throw new AssumptionFailedError("Config type is unknown, has not been set or not detected");
		}

		Filesystem::safeFilePutContents($this->file, $content);

		$this->changed = false;
	}
}