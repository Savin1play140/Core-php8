<?php
namespace server\Core\utils;

class TypeConfig {
	public static $format = [
		"json",
		"yml"
	];
}