<?php
namespace server\Core\utils;


class Popup {
	private $name;
	private $label;
	private $color = [];
	public function __construct($name, $label, $background) {
		$this->name = $name;
		$this->label = $label;
		$this->color["background"] = $background;
	}
	public function getName() {
		return $this->name;
	}
	public function getLabel() {
		return $this->label;
	}
	public function getBackground() {
		return $this->color["background"];
	}
}