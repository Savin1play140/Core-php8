<?php
namespace server\Core\utils;

class Manager {
	public function __constants() {}
	//Plugins
	public function loadPlugin(string $file) {
		@include_once $_SERVER["DOCUMENT_ROOT"]."/plugins/".$file."/Main.php";
	}
	public function loadPlugins() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/plugins/";
		$files = scandir($dir);
		foreach ($files as $file) {
			if (!str_contains($file, ".")) {
				echo "[SERVER-LOG-ALERT] plugin ".$file." enabled!<br>";
				$plugs = scandir($dir.$file."/src");
				foreach ($plugs as $plug) {
					@include_once $dir.$file."/src/".$plug;
				}
			}
		}
	} //Textures
	public function loadTextures() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/textures/";
		$files = scandir($dir);
		foreach ($files as $zip) {
			if (!str_contains($zip, ".")) {
				if (is_dir($dir.$zip)) {
					$content = file_get_contents($dir.$zip."/manifest.json");
					$texture = json_decode($content, true);
					echo "[SERVER-LOG-ALERT] dir \"".$dir.$zip."\" found <br>";
				}
			}
		}
	}
	public function loadTexture($zip) {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/textures/";
		if (!str_contains($zip, ".")) {
			if (is_dir($dir.$zip)) {
				$content = file_get_contents($dir.$zip."/manifest.json");
				$texture = json_decode($content, true);
				echo "[SERVER-LOG-ALERT] dir \"".$dir.$zip."\" found <br>";
			}
		}
	}
}