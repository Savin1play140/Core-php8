<?php
namespace server\Core\blocks;
class BlockGenerator {
	private $filename;
	private $file;
	private $data;
	public function __construct($name) {
		$this->filename = "$name.json";
		$this->data = json_decode(file_get_contents("php://input"));
		if (file_exists($this->filename)) {
			$this->file = file_get_contents($this->filename);
		} else {
			$this->file = fopen($this->filename, "a+");
		}
	}
	public function generat($id = 01,
		array $func = array(
			"minecraft:destroy_time" => 1,
			"minecraft:explosion_resistance" => 1,
			"minecraft:block_light_absorption" => 0,
			"minecraft:loot" => "",
			"minecraft:pick_collision" => array(
				"origin" => [-8,0,-8],
				"size" => [16,16,16]
			)
		)
	) {
	$arr = array(
			"format_version" => "1.16.200",
			"minecraft:block" => array(
				"description" => array(
					"identifier" => "kyb:$id"
				)
			),
			"components" => $func
		);
		$taskList = json_decode($this->filename, true);
		$taskList = $arr;
		file_put_contents($this->filename, json_encode($taskList));
	}
}