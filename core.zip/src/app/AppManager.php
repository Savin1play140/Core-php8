<?php
namespace server\Core\app;
use server\Core\Server;
use server\Core\system\Log;
class AppManager {
	public function __construct(
		private Server $server,
		private Log $log
	) {}
	public function loadAll() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/apps/";
		@mkdir($dir);
		$files = scandir($dir);
		foreach ($files as $file) {
			if (!str_contains($file, ".")) {
				echo "[SERVER-LOG-ALERT] plugin $file enabled!<br>";
				$plugs = scandir($dir.$file."/");
				foreach ($plugs as $plug) {
					@include_once $dir.$file."/".$plug;
					$plug = $plug !== ".." ? $plug : null;
					$plug = $plug !== "." ? $plug : null;
					if ($plug != null) {
						$class = str_replace(".php", "", $plug);
						$plugin = new $class($this->server, $this->log, $this);
						if (!$plugin instanceof PluginBase) {
							throw new \PluginError("plugin does not inherit class PluginBase! in file \"$dir$file/src/$plug\" a plugin $file");
						}
					}
				}
			}
		}
	}
}