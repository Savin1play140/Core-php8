<?php
namespace server\Core\math;

class Calc {
	public function __construct($a,$b){
		$this->a = $a;
		$this->b = $b;
	}
	public function multiply() {
			return $this->a * $this->b;
	}
	public function plus() {
			return $this->a + $this->b;
	}
	public function minus() {
			return $this->a - $this->b;
	}
	public function divide() {
			return $this->a / $this->b;
	}
}
?>