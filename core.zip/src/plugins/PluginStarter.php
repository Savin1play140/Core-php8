<?php
namespace server\Core\plugins;
use server\Core\Server;
use server\Core\system\Log;

class PluginStarter {
	private $cl;
	public function __construct($class) {
		$this->cl = $class;
	}
	public function start() {
		$this->cl->onEnable();
	}
}