<?php
namespace server\Core\network;
use server\Core\Server;
use server\Core\system\Log;

class Console implements Sender {
	private $server;
	private $file;
	public function __construct(Server $server) {
		$this->server = $server;
		$this->file = fopen($_SERVER["DOCUMENT_ROOT"]."/server.log", "a+");
	}
	public function getName(): string {
		return "CONSOLE";
	}
	public function getServer(): Server {
		return $this->server;
	}
	public function sendMessage(string $message):void {
		fwrite($this->file, "[".date("Y.m.d H:i:s")."]: ".$message."\n");
	}
	public function sendLog() {
		echo fread($this->file, filesize(__DIR__."/server.log"));
	}
	public function __destruct() {
		fclose($this->file);
	}
}