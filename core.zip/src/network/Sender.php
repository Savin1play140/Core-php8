<?php

namespace server\Core\network;

use server\Core\Server;

interface Sender {
	public function getName():string;
	public function getServer():Server;
	public function sendMessage(string $message):void;
}