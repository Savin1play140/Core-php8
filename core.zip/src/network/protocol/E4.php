<?php
$content = file_get_contents($_SERVER["DOCUMENT_ROOT"]."/core/src/network/protocol/protocol.json");
$texture = json_decode($content, true);
//print_r($texture);
?>
<html>
	<head>
		<title><? echo $texture["E4"]["error"]; ?></title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body>
		<h1><? echo $texture["E4"]["lable"]; ?></h1>
		<h2><? echo $texture["E4"]["text"]; ?></h2>
		<p><br><br><br><br></p>
		<h3>author: <? echo $texture["author"]; ?></h3>
	</body>
</html><? exit; ?>