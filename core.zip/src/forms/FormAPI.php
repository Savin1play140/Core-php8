<?php
namespace server\Core\forms;

class FormAPI {
	private $form;
	public function __construct(Form $form) {
		$this->form = $form;
	}
}
// $api = new FormAPI(new Form(name, title, type = 0));